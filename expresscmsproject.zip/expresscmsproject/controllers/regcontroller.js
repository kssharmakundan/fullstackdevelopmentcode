const Reg=require('../models/reg')
const nodemailer=require('nodemailer')





exports.loginpage=(req,res)=>{
    res.render('login.ejs',{message:'',loginemail:''})
}

exports.regpage=(req,res)=>{
    res.render('reg.ejs',{message:'',css:'',loginemail:''})
}

exports.reg=async(req,res)=>{
    const{us,pass}=req.body
    try{
    const usercheck=await Reg.findOne({email:us})
    if(usercheck==null){
    
    const record=new Reg({email:us,password:pass})
    record.save()
    res.render('reg.ejs',{message:'Successfully Created',css:'success',loginemail:''})
}else{
    res.render('reg.ejs',{message:'Email id already taken',css:'warning',loginemail:''})
}
}catch(error){
    console.log('Error --->'+error.message)
    res.render('reg.ejs',{message:error.message,css:'danger',loginemail:''})
}
}

exports.logincheck=async(req,res)=>{
    const{email,pass}=req.body
    const emailcheck=await Reg.findOne({email:email})
    console.log(emailcheck)
    if(emailcheck!==null){
        if(emailcheck.password==pass){
            if(emailcheck.status=='active' || email=='admin@gmail.com'){
            req.session.isAuth=true
            req.session.loginemail=email
            req.session.role=emailcheck.role
            if(email=='admin@gmail.com'){
                res.redirect('/admin/dashboard')
            }else{
                res.redirect('/usersprofile')
            }

        }else{
            res.render('login.ejs',{message:'Your account is suspended please coordinate with your admin',loginemail:'' })  
        }


        }
        
        
        else{
            res.render('login.ejs',{message:'Wrong Credentials',loginemail:'' })
        }

    }else{
        res.render('login.ejs',{message:'Wrong Credentials',loginemail:'' })
    }
}

exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}

exports.userprofile=async(req,res)=>{
    const loginemail=req.session.loginemail
    const record=await Reg.find({img:{$nin:['default.jpg']}})
    //console.log(record)
    res.render('usersprofile.ejs',{loginemail,record})
}

exports.forgot=(req,res)=>{
    res.render('forgot.ejs',{loginemail:'',message:''})
}

exports.forgotlink=async(req,res)=>{
    const{email}=req.body
    const emailcheck=await Reg.findOne({email:email})
    if(emailcheck!==null){
        let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'electricaldevelopersk@gmail.com', // generated ethereal user
        pass: 'qjmstwkufmigqygc', // generated ethereal password
      },
    });
    console.log("connected to smtp server")
    let info = await transporter.sendMail({
        from: 'electricaldevelopersk@gmail.com', // sender address
        to: email, // list of receivers
        subject: 'Change Password Link', // Subject line
        text: 'Please click on below link to reset your password', // plain text body
        html: `<a href='http://localhost:5000/resetform/${email}>RESET</a>`, // html body
       
      });
      console.log("email sent")
      res.render('forgot.ejs',{message:"Successfully Email sent to Registered Email Id",loginemail:''})

    }else{
       res.render('forgot.ejs',{loginemail:'',message:'Email not registered'}) 
    }

}

exports.resetform=(req,res)=>{
    const email=req.params.email
    res.render('resetform.ejs',{loginemail:'',message:'',email})
}

exports.passwordchange=async(req,res)=>{
    const {pass}=req.body
    const email=req.params.email
    const record=await Reg.findOne({email:email})
    if(record.password!==pass){
    const id=record.id
    await Reg.findByIdAndUpdate(id,{password:pass})
    res.render('resetmessage.ejs',{message:'Password Successfully Changed, Please login with new password',loginemail:''})
    }else{
        res.render('resetform.ejs',{message:'You dont use the previous used password',loginemail:'',email:email})
    }
}

exports.dashboard=(req,res)=>{
    const email=req.session.loginemail
    res.render('admin/dashboard.ejs',{email})
}

exports.userspages=async(req,res)=>{
    const record=await Reg.find()
    const email=req.session.loginemail
    res.render('admin/users.ejs',{email,record,message:''})
}

exports.userstatusupdate=async(req,res)=>{
    const id=req.params.id
    const record1=await Reg.findById(id)
    let newstatus=null
    if(record1.status=='suspended'){
        newstatus='active'

    }else{
        newstatus='suspended'
    }
    await Reg.findByIdAndUpdate(id,{status:newstatus})
    const email=req.session.loginemail
    const record=await Reg.find()
    res.render('admin/users.ejs',{message:'Successfully Status Updated',email,record})

}

exports.profileupdatepage=async(req,res)=>{
    const email=req.session.loginemail
    const record=await Reg.findOne({email:email})
    res.render('profileupdateform.ejs',{loginemail:email,record,message:''})
}

exports.profileupdate=async(req,res)=>{
    const filename=req.file.filename
    const {fname,lname,mobile,about}=req.body
    const email=req.session.loginemail
    const userdata=await Reg.findOne({email:email})
    const id=userdata.id
    await Reg.findByIdAndUpdate(id,{firstName:fname,lastName:lname,mobile:mobile,img:filename,desc:about})
    const record=await Reg.findOne({email:email})
    res.render('profileupdateform.ejs',{message:'Successfully profile has been updated',loginemail:email,record})
}

exports.userdelete=async(req,res)=>{
    const id=req.params.id
    await Reg.findByIdAndDelete(id)
    const email=req.session.loginemail
    const record=await Reg.find()
    res.render('admin/users.ejs',{message:'Successfully Deleted',record,email})
}

exports.singledetails=async(req,res)=>{
    const id=req.params.id
    const singlerecord=await Reg.findById(id)
    const email=req.session.loginemail
    res.render('singledetail.ejs',{loginemail:email,singlerecord})
}

exports.usersroleupdate=async(req,res)=>{
    const id=req.params.id
    const record1=await Reg.findById(id)
    let currentstatus=null
    if(record1.role=='free'){
        currentstatus='subscribed'
    }else{
        currentstatus='free'
    }
    await Reg.findByIdAndUpdate(id,{role:currentstatus})
    const email=req.session.loginemail
    const record=await Reg.find()
    res.render('admin/users.ejs',{email,record,message:'Successfully Role has been Updated'})
}