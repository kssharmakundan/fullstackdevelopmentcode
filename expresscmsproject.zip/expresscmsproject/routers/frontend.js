const router=require('express').Router()
const { Router } = require('express')
const regc=require('../controllers/regcontroller')
const multer=require('multer')



let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/profileimages')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})
let upload=multer({
    storage:storage,
    limits:{fileSize:4*1024*1024}
})


function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/')
    }
}

function handlerole(req,res,next){
    if(req.session.role!=='free'){
        next()
    }else{
        res.send("You don't have subscription to see the contact details. Please subscribe")
    }
}






router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/reg',regc.regpage)
router.post('/reg',regc.reg)
router.get('/logout',regc.logout)
router.get('/usersprofile',regc.userprofile)
router.get('/forgot',regc.forgot)
router.post('/forgot',regc.forgotlink)
router.get('/resetform/:email',regc.resetform)
router.post('/resetform/:email',regc.passwordchange)
router.get('/profile',regc.profileupdatepage)
router.post('/profile',upload.single('img'),regc.profileupdate)
router.get('/singledetail/:id',handlerole,regc.singledetails)














module.exports=router