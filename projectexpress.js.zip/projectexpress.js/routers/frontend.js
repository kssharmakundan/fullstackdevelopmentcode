const router=require('express').Router()
const bannerc=require('../controllers/bannercontroller')
const regc=require('../controllers/regcontroller')
const Banner=require('../models/banner')
const Service=require('../models/service')
const servicec=require('../controllers/servicecontroller')
const testc=require('../controllers/testicontroller')
const Testi=require('../models/testi')
const queryc=require('../controllers/querycontroller')
const addressc=require('../controllers/addresscontroller')
const Address=require('../models/address')

const multer=require('multer')

let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{filesize:1024*1024*4}
})




router.get('/',async(req,res)=>{
    const record=await Banner.findOne()
    const service=await Service.find({status:'publish'})
    const testi=await Testi.find({status:'publish'})
    const testicount=await Testi.count()
    const address=await Address.findOne()
  
    //console.log(record)
    res.render('index.ejs',{record,service,testi,testicount,address})
   
})

router.get('/banner',bannerc.bannerpageshow)

router.get('/servicemore/:id',servicec.servicemoredetails)

router.get('/testi',testc.testiform)
router.post('/testirecord',upload.single('img') ,testc.testiinsert)

router.post('/queryrecord',queryc.queryrecords)







module.exports=router