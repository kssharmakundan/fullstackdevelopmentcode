const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const bannerc=require('../controllers/bannercontroller')
const servicec=require('../controllers/servicecontroller')
const testc=require('../controllers/testicontroller')
const queryc=require('../controllers/querycontroller')
const addressc=require('../controllers/addresscontroller')



const multer=require('multer')



let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null, Date.now()+file.originalname)
    }
})

let upload=multer({
    storage:storage,
    limits:{filesize:1024*1024*4}
})

function handlelogin(req,res,next){
    if(req.session.isAuth){
        next()
    }else{
        res.redirect('/admin/')
    }
}





router.get('/',regc.adminloginshow)
router.post('/loginrecord',regc.adminlogincheck)

router.get('/dashboard',handlelogin,regc.dashboardshow)

router.get('/banner',bannerc.banner)

router.get('/logout',regc.logout)

router.get('/bannerupdate/:abc',bannerc.bannerupdate)

router.post('/bannerupdate/:id',upload.single('img'),bannerc.bannerrecord)

router.get('/services',servicec.adminpageshow)

router.get('/serviceadd',servicec.adminserviceform)

router.post('/serviceaddrecord',upload.single('img'),servicec.adminserviceadd)

router.get('/servicedelete/:id',servicec.servicedelete)
router.get('/servicestatusupdate/:id',servicec.servicestatusupdate)

router.get('/testi',testc.adminpageshow)

router.get('/testistatusupdate/:id',testc.testistatusupdate)
router.get('/testidelete/:id',testc.testidelete)

router.get('/query',queryc.querypageshow)
router.get('/queryreply/:id',queryc.queryreplyform)
router.post('/replyrecords/:id',upload.single('attachment'),queryc.emailsend)
router.get('/address',addressc.addressshow)
router.get('/addressupdate/:id',addressc.addressupdateshow)
router.post('/addressrecords/:id',addressc.addressupdate)
router.post('/servicesearch',servicec.servicesearch)
router.post('/testisearch',testc.testisearch)







module.exports=router