const Address=require('../models/address')


exports.addressshow=async(req,res)=>{
    const record=await Address.findOne()
    res.render('admin/address.ejs',{record})
}

exports.addressupdateshow=async(req,res)=>{
    const id=req.params.id
    const record=await Address.findById(id)
    res.render('admin/addressform.ejs',{record})
}

exports.addressupdate=async(req,res)=>{
    const id=req.params.id
    const{add,phone,mobile,email,insta,twitter,linkdn,snap}=req.body
    await Address.findByIdAndUpdate(id,{add:add,phone:phone,mobile:mobile,email:email,insta:insta,twitter:twitter,linkdn:linkdn,snap:snap})
    res.redirect('/admin/address')

}