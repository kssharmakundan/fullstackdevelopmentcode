const Service=require('../models/service')
const Address=require('../models/address')



exports.adminpageshow=async(req,res)=>{
    const record=await Service.find().sort({postedDate:-1})
    const totalServices=await Service.count()
    const publish=await Service.count({status:'publish'})
    const unpublish=await Service.count({status:'unpublish'})
    //console.log(totalServices)
    res.render('admin/service.ejs',{record,totalServices,publish,unpublish})
}


exports.adminserviceform=(req,res)=>{
    res.render('admin/serviceform.ejs')
}

exports.adminserviceadd=(req,res)=>{
    const{sname,sdesc,sldes}=req.body
    const filename=req.file.filename
    const record=new Service({img:filename,name:sname,desc:sdesc,ldesc:sldes})
    record.save()
    //console.log(record)
    res.redirect('/admin/services')
}

exports.servicedelete=async(req,res)=>{
    const id=req.params.id
    await Service.findByIdAndDelete(id)
    res.redirect('/admin/services')
}

exports.servicestatusupdate=async(req,res)=>{
    const id=req.params.id
    const record=await Service.findById(id)
    //console.log(record)
    let newstatus=null
    if(record.status=='unpublish'){
        newstatus='publish'
    }else{
        newstatus='unpublish'
    }

    await Service.findByIdAndUpdate(id,{status:newstatus})
    res.redirect('/admin/services')

}

exports.servicemoredetails=async(req,res)=>{
    const id=req.params.id
    const record=await Service.findById(id)
    const address=await Address.findOne()
    res.render('servicesdetails',{record,address})
}

exports.servicesearch=async(req,res)=>{
    const {search}=req.body
    const totalServices=await Service.count()
    const publish=await Service.count({status:'publish'})
    const unpublish=await Service.count({status:'unpublish'})
    const record=await Service.find({status:search})
    res.render('admin/service.ejs',{record,totalServices,publish,unpublish})

}
