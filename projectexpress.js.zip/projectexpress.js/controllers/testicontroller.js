const Testi=require('../models/testi')
const Address=require('../models/address')


exports.testiform=async(req,res)=>{
    const address=await Address.findOne()
    res.render('testiform.ejs',{address})
}

exports.testiinsert=(req,res)=>{
    const{quotes,cname}=req.body
    const filename=req.file.filename
    const record=new Testi({img:filename,quotes:quotes,name:cname})
    record.save()
    //console.log(record)
    res.redirect('/admin/testi')
}

exports.adminpageshow=async(req,res)=>{
    const record=await Testi.find()
    const totalTestis=await Testi.count()
    const publish=await Testi.count({status:'publish'})
    const unpublish=await Testi.count({status:'unpublish'})
    //console.log(totalTesti)
    res.render('admin/testi.ejs',{record,totalTestis,publish,unpublish})
}

exports.testistatusupdate=async(req,res)=>{
    const id=req.params.id
    const record=await Testi.findById(id)
    let newstatus=null
    if(record.status=='unpublish'){
        newstatus='publish'
    }else{
        newstatus='unpublish'
    } 
    await Testi.findByIdAndUpdate(id,{status:newstatus})  
    res.redirect('/admin/testi')

}

exports.testidelete=async(req,res)=>{
    const id=req.params.id
    await Testi.findByIdAndDelete(id)
    res.redirect('/admin/testi')
}

exports.testisearch=async(req,res)=>{
    const {search}=req.body
    const totalTestis=await Testi.count()
    const publish=await Testi.count({status:'publish'})
    const unpublish=await Testi.count({status:'unpublish'})
    
    const record=await Testi.find({status:search})
    res.render('admin/testi.ejs',{record,totalTestis,publish,unpublish})

}


