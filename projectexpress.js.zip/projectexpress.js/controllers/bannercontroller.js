const Banner=require('../models/banner')
const Address=require('../models/address')



exports.banner=async(req,res)=>{
    const record=await Banner.findOne()
    res.render('admin/banner.ejs',{record,message:''})
}

exports.bannerupdate=async(req,res)=>{
    const id=req.params.abc
    const record=await Banner.findById(id)
    res.render('admin/bannerform.ejs',{record})
}

exports.bannerrecord=async(req,res)=>{
    const{title,desc,ldesc}=req.body
    const id=req.params.id
    if(req.file){
        const filename=req.file.filename
   await Banner.findByIdAndUpdate(id,{title:title,desc:desc,ldesc:ldesc,img:filename})
   }else{
       await Banner.findByIdAndUpdate(id,{title:title,desc:desc,ldesc:ldesc})
   }
 

   
    const record=await Banner.findOne()
    res.render('admin/banner.ejs',{record,message:'Successfully Updated'})
    
}

exports.bannerpageshow=async(req,res)=>{
    
    const record=await Banner.findOne()
    const address=await Address.findOne()
    //console.log(record)
    res.render('banner.ejs',{record,address})
}