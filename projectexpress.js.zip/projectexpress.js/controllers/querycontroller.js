const Query=require('../models/query.js')
const nodemailer=require('nodemailer')


exports.queryrecords=(req,res)=>{
    const{email,query}=req.body
    const record=new Query({query:query,email:email})
    record.save()
    res.redirect('/')
    //console.log(record)
}

exports.querypageshow=async(req,res)=>{
    const record=await Query.find()
    res.render('admin/query.ejs',{record})
}

exports.queryreplyform=async(req,res)=>{
    const id=req.params.id
    const record=await Query.findById(id)
    res.render('admin/queryform.ejs',{record})
}

exports.emailsend=async(req,res)=>{
  const id=req.params.id
    const path=req.file.path
    const{emailto,fromto,subject,body}=req.body
    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'electricaldevelopersk@gmail.com', // generated ethereal user
        pass: 'qjmstwkufmigqygc', // generated ethereal password
      },
    });
    console.log("connected to smtp server")
    let info = await transporter.sendMail({
        from: fromto, // sender address
        to: emailto, // list of receivers
        subject: subject, // Subject line
        text: body, // plain text body
        //html: "<b>Hello world?</b>", // html body
        attachments:[{
            path:path
        }]
      });
      console.log("email sent")
      await Query.findByIdAndUpdate(id,{status:'Replied'})
      res.redirect('/admin/query')
}