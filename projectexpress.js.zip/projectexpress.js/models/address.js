const mongoose=require('mongoose')


const addressSchema=mongoose.Schema({
    add:String,
    phone:Number,
    mobile:Number,
    email:String,
    insta:String,
    twitter:String,
    linkdn:String,
    snap:String



})









module.exports=mongoose.model('address',addressSchema)