const express=require('express')//function
const app=express()//module
app.use(express.urlencoded({extended:false}))
const frontendRouter=require('./routers/frontend')
const adminRouter=require('./routers/admin')
require('dotenv').config()
const mongoose=require('mongoose')
const session=require('express-session')
mongoose.connect(process.env.DB_URL+'/'+process.env.DB_NAME)






app.use(session({
    secret:process.env.S_KEY,
    resave:false,
    saveUninitialized:false

}))
app.use(express.static('public'))
app.use(frontendRouter)
app.use('/admin',adminRouter)
app.set('view engine','ejs')

app.listen(process.env.PORT)