const http=require('http') //module
const fs=require('fs')
const homehtml=fs.readFileSync('./home.html')
const stylecss=fs.readFileSync('./style.css')
const img1=fs.readFileSync('./flashtesla.jpeg')
//console.log(homehtml)

const server=http.createServer((req,res)=>{
     if(req.url==='/'){
        res.write(homehtml)
        res.end()
     }
     else if(req.url==='/about'){
        res.end('Welcome to about Page')
     }else if(req.url==='/style.css'){
        res.write(stylecss)
        res.end()
     }else if(req.url==='/flashtesla.jpeg'){
        res.write(img1)
        res.end()
      }
     else{
          res.end("page not found")
     }



})


server.listen(5000)