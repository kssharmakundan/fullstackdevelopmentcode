const os=require('path')//module

console.log(__dirname)
console.log(__filename)
console.log

