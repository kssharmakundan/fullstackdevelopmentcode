function add(){
    console.log("hello")
}






module.exports=add