const express=require('express') // function
const app=express() //module
app.use(express.urlencoded({extended:false}))

const testRouter=require('./router/test')
const adminRouter=require('./router/admin')

const mongoose=require('mongoose')//module
const session=require('express-session')//module

mongoose.connect('mongodb://127.0.0.1:27017/6pmthirdnode')



app.use(session({
    secret:'kundan',
    saveUninitialized:false,
    resave:false
}))
app.use('/admin',adminRouter)
app.use(testRouter)//frontend user

app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(5000)