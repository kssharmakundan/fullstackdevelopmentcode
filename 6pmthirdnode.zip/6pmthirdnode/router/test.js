const router=require('express').Router()//module


const Student=require('../models/student')
const Emp=require('../models/emp')
const { response } = require('express')
const student = require('../models/student')
const multer=require('multer')
const nodemailer=require('nodemailer')//module
const Reg=require('../models/reg')

function handlelogin(req,res,next){
  if(req.session.isAuth){
    next()
  }else{
    res.redirect('/login')
  }
}



let storage=multer.diskStorage({
    destination:function(req,file,cb){
        cb(null,'./public/upload')
    },
    filename:function(req,file,cb){
        cb(null,Date.now()+file.originalname)
    }
})
let upload=multer({
    storage:storage,
    limits:{fileSize:1024*1024*4}
})



router.get('/',(req,res)=>{
    let name='kundan'
    let address='jaipur'
    res.render('home.ejs',{name,address})
    //res.send('welcome to home page')
})
router.get('/about',(req,res)=>{
    res.render('about.ejs')
    //res.send('welcome to about page')
})

router.get('/contact',(req,res)=>{
    res.send("Welcome to Contact")
})

router.get('/form',(req,res)=>{
    res.render('form.ejs')
})

router.post('/formrecords',(req,res)=>{
    console.log(req.body)
})


router.get('/updates/:name',(req,res)=>{
    console.log(req.params.name)

})

router.get('/insertform',(req,res)=>{
    res.render('insertform.ejs')
})

router.post('/insertdata',upload.single('img'),(req,res)=>{
    //console.log(req.file)
    //console.log(req.body)
    const filename=req.file.filename
    const{sname,sclass,marks}=req.body
    const record=new Student({name:sname,class:sclass,marks:marks,img:filename})
    record.save()
    res.redirect('/mselection')
})


router.get('/selection',async(req,res)=>{
    const record= await Student.findOne()
    //console.log(record)
    res.render('selection.ejs',{record})
})

router.get('/mselection',handlelogin,async(req,res)=>{
    const record=await Student.find()
    //console.log(record)
    res.render('mselection.ejs',{record})
})

router.get('/delete/:abc',async(req,res)=>{
    const id=req.params.abc
    await Student.findByIdAndDelete(id)
    res.redirect('/mselection')
})

router.get('/update/:xyz',async(req,res)=>{
    const id=req.params.xyz
    const record=await Student.findById(id)
    res.render('updateform.ejs',{record})
})

router.post('/updaterecord/:tt',async(req,res)=>{
    const id=req.params.tt
    const{sname,sclass,smarks}=req.body
    await Student.findByIdAndUpdate(id,{name:sname,class:sclass,marks:smarks})
    res.redirect('/mselection')
})





router.get('/email',(req,res)=>{
     res.render('emailform.ejs')
})


router.post('/sendmail',upload.single('attachment'),async(req,res)=>{
    const filepath=req.file.path
    const{emailto,emailfrom,subject,body}=req.body
  
    let testAccount = await nodemailer.createTestAccount();

    // create reusable transporter object using the default SMTP transport
    let transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false, // true for 465, false for other ports
      auth: {
        user: 'electricaldevelopersk@gmail.com', // generated ethereal user
        pass: 'qjmstwkufmigqygc', // generated ethereal password
      },
    });

    console.log("connected to SMTP server")

    let info = await transporter.sendMail({
        from:'emailfrom', // sender address
        to:emailto, // list of receivers
        subject:subject, // Subject line
        text:body, // plain text body
        html:'<table border="1" style="border-collapse: collapse;"><tr><th>Name</th><th>Address</th></tr><tr><td>Kundan</td><td>Jaipur</td></tr></table>', // html body
        attachments:[{
            path:filepath
        }]
    });

      console.log("email sent")
})



router.get('/reg',(req,res)=>{
    res.render('reg.ejs')

})
router.post('/regrecord',async(req,res)=>{
    const{us,pass}=req.body
    const usercheck=await Reg.findOne({username:us})
    //console.log(usercheck)
    if(usercheck==null){
    const record=new Reg({username:us,password:pass})
    record.save()
    }else{
        res.send("username already taken")
    }
})


router.get('/login',(req,res)=>{
    res.render('login.ejs')
})
router.post('/loginrecord',async(req,res)=>{
    const{username,password}=req.body
const record=await Reg.findOne({username:username})
console.log(record)
if(record!==null){
   if(record.password==password){
    req.session.isAuth=true
    res.redirect('/mselection')
}else{
    res.redirect('/login')
}
}else{
    res.redirect('/login')
}
})

router.get('/logout',(req,res)=>{
    req.session.destroy()
    res.redirect('/login')

})



module.exports=router




