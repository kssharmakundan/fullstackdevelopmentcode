const router=require('express').Router()


router.get('/',(req,res)=>{
    res.send("welcome to admin")
})








module.exports=router