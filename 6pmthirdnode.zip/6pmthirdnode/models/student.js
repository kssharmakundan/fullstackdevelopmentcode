const mongoose=require('mongoose')//module

let studentSchema=mongoose.Schema({
    name:String,
    class:String,
    marks:Number,
    img:String
})



module.exports=mongoose.model('student',studentSchema)

