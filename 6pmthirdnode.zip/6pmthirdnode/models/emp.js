const mongoose=require('mongoose')


const empSchema=mongoose.Schema({
    name:String,
    dept:String,
    salary:Number,
    img:String
    
})

module.exports=mongoose.model('emp',empSchema)
