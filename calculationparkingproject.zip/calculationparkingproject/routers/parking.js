const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const parkingc=require('../controllers/parkingcontroller')

router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/parking',parkingc.parkingdetails)
router.get('/add',parkingc.parkingform)
router.post('/add',parkingc.add)
router.get('/parkingupdate/:id',parkingc.update)
router.get('/parkingprint/:id',parkingc.waytoprint)








module.exports=router