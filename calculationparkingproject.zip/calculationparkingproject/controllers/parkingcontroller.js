const Parking=require('../models/parking')



exports.parkingdetails=async(req,res)=>{
    const record=await Parking.find()
    res.render('parking.ejs',{record})
}

exports.parkingform=(req,res)=>{
    res.render('parkingform.ejs')
}

exports.add=(req,res)=>{
    const{vn,vtype}=req.body
    let currentDateAndTime=new Date()
    const record=new Parking({vno:vn,vtype:vtype,vin:currentDateAndTime,})
    record.save()
    res.redirect('/parking')
}

exports.update=async(req,res)=>{
    const id=req.params.id
    const record=await Parking.findById(id)
    let vouttime=new Date()
    let spendTimeParking=Math.round((vouttime-record.vin)/(1000*60*60))
    //console.log(spendTimeParking)
    let amount=0
    if(record.vtype=='2w'){
        amount=spendTimeParking*20
    }else if(record.vtype=='3w'){
        amount=spendTimeParking*30 
    }else if(record.vtype=='4w'){
        amount=spendTimeParking*100
    }else if(record.vtype=='hw'){
        amount=spendTimeParking*300 
    }else if(record.vtype=='lw'){
        amount=spendTimeParking*200
    }else{
        amount=spendTimeParking*120
    }
    if(amount==0){
        amount=10
    }

    await Parking.findByIdAndUpdate(id,{vout:vouttime,amount:Math.round(amount),status:'OUT'})
    res.redirect('/parking')
}

exports.waytoprint=async(req,res)=>{
    const id=req.params.id
    const record=await Parking.findById(id)
    res.render('printpage.ejs',{record})
}